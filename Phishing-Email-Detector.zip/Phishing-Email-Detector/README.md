# Phishing-Email-Detector
For my final year project , i created a phishing detector model using hybrid machine learning approach .
I used python , jupyter notebook , streamlit , html and css throughout this project . 

# Finding
The project concludes that the proposed tuned hybrid model achieved high performance with an accuracy of 93.8%, a precision of 1.0, a recall of 
87.5%, and an F1-score of 94% and provides valuable insights into the application of
machine learning for detecting phishing email and emphasizes the value of mixing different 
models for enhanced performance.

# Extra info :
Attached a research paper about this whole project as a explaination and reference.
