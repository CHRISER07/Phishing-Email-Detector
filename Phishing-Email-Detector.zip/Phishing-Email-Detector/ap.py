import streamlit as st
import pickle
import string
from nltk.corpus import stopwords
import nltk
from nltk.stem.porter import PorterStemmer
from PIL import Image
import pyttsx3

# Initialize PorterStemmer and TTS engine
ps = PorterStemmer()

def speak(text):
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

# Load and display header image
image = Image.open('Screenshot 2025-01-28 000557.png')
col1, col2, col3 = st.columns(3)
col2.image(image, width=250)

# Function to preprocess the text
def transform_text(text):
    text = text.lower()
    text = nltk.word_tokenize(text)
    y = []

    for i in text: 
        if i.isalnum():
            y.append(i)

    text = y[:]
    y.clear()

    for i in text:
        if i not in stopwords.words('english') and i not in string.punctuation:
            y.append(i)

    text = y[:]
    y.clear()

    for i in text:
        y.append(ps.stem(i))

    return " ".join(y)

# Title of the Streamlit app
html_temp = """
    <div style="background-color:#662d91;padding:10px">
    <h2 style="color:white;text-align:center;"> Phishing Email Detector/Classifier </h2>
    </div>
    """
st.markdown(html_temp, unsafe_allow_html=True)

# Load pre-trained model and vectorizer
tfidf = pickle.load(open('vectorizer.pkl', 'rb'))
model = pickle.load(open('hybridTunedModel.pkl', 'rb'))

# User input for phishing message detection
st.subheader('Test Your Own Message')
user_subject = st.text_input('Enter the email subject:')
user_text = st.text_area('Enter the email content:')

if st.button('Predict'):
    user_content = user_subject + ' ' + user_text
    transformed_content = transform_text(user_content)
    user_content_vec = tfidf.transform([transformed_content])

    # Ensure correct format for prediction
    if hasattr(user_content_vec, 'toarray'):
        user_content_vec = user_content_vec.toarray()

    prediction = model.predict(user_content_vec)

    if prediction[0] == 1:
        st.header("Phishing Email")
        speak("This is a Phishing Email")
    else:
        st.header("Legitimate Email")
        speak("This is a Legitimate Email")
